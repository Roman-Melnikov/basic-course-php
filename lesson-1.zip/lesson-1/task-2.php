<?php
$name = readline('Как вас зовут?');
$age = readline('Сколько вам лет?');
echo "Вас зовут $name, вам возраст $age лет";

