<?php
$heading = 'Информация обо мне';
$year = 2019;

include "./site.html";
